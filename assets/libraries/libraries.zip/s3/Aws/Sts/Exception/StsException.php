<?php
namespace Aws\Sts\Exception;

use Aws\Exception\AwsException;

/**
 * AWS Security Token Service exception.
 */
class StsException extends AwsException {}
