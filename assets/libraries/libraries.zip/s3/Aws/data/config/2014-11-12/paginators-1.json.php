<?php
// This file was auto-generated from sdk-root/src/data/config/2014-11-12/paginators-1.json
return [ 'pagination' => [ 'GetResourceConfigHistory' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'limit', 'result_key' => 'configurationItems', ], ],];
